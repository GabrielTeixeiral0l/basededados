-- =============================================================================
-- SCRIPT DE TESTES UNITÁRIOS E INTEGRADOS (FINAL - ROBUSTO)
-- =============================================================================
SET SERVEROUTPUT ON;
SET FEEDBACK ON;

PROMPT === INICIANDO LIMPEZA DE DADOS DE TESTE ===



PROMPT === INSERINDO DADOS DE CONFIGURAÇÃO ===

INSERT INTO estado_matricula (id, nome) VALUES (1, 'Ativa');
INSERT INTO estado_matricula (id, nome) VALUES (2, 'Concluída');

INSERT INTO tipo_curso (id, nome, valor_propinas) VALUES (1, 'Licenciatura', 1000);
INSERT INTO tipo_aula (id, nome) VALUES (1, 'Teórica');
INSERT INTO tipo_avaliacao (id, nome, descricao, requer_entrega, permite_grupo, permite_filhos) 
VALUES (1, 'Exame', 'Exame Final', '0', '0', '1');

INSERT INTO sala (id, nome, capacidade) VALUES (1, 'Sala 101', 30);

PROMPT === TESTE 1: INSERÇÃO DE ESTUDANTE ===
INSERT INTO estudante (id,nome, morada, data_nascimento, cc, nif, email, telemovel)
VALUES (1232332132,'Joao Silva', 'Rua A', TO_DATE('2000-01-01','YYYY-MM-DD'), '123456789ZZ0', '123456789', 'joao@email.com', '911111111');

PROMPT === TESTE 2: CURSOS E MATRÍCULAS ===
INSERT INTO curso (id, nome, codigo, descricao, duracao, ects, max_alunos, tipo_curso_id)
VALUES (1, 'Engenharia', 'ENG-INF', 'Eng. Informática', 3, 180, 30, 1);

INSERT INTO matricula (id, curso_id, estudante_id, estado_matricula_id, ano_inscricao, numero_parcelas)
VALUES (1, 1, 1, 1, 2025, 10);

PROMPT === TESTE 3: UNIDADE CURRICULAR E DOCENTE ===
INSERT INTO unidade_curricular (id, nome, codigo, horas_teoricas, horas_praticas)
VALUES (1, 'Base de Dados', 'BD1', 40, 20);

INSERT INTO uc_curso (curso_id, unidade_curricular_id, obrigatoria, semestre, ano, ects, status)
VALUES (1, 1, '1', 1, 1, 6, '1');

INSERT INTO docente (id, nome, data_contratacao, nif, cc, email, telemovel)
VALUES (1, 'Prof. Alberto', SYSDATE, '500123456', '987654321ZX0', 'alberto@docente.com', '933333333');

PROMPT === TESTE 4: TURMA E INSCRIÇÃO ===
INSERT INTO turma (id, nome, ano_letivo, unidade_curricular_id, max_alunos, docente_id)
VALUES (1, 'Turma A', '2025/26', 1, 20, 1);

INSERT INTO inscricao (id, turma_id, matricula_id, data)
VALUES (1, 1, 1, SYSDATE);

PROMPT === TESTE 5: AULAS E PRESENÇAS ===
-- A inserção da aula deve disparar o trigger que cria presenças para os inscritos
INSERT INTO aula (id, data, hora_inicio, hora_fim, sumario, tipo_aula_id, sala_id, turma_id)
VALUES (1, SYSDATE, SYSDATE, SYSDATE+1/24, 'Aula inicial', 1, 1, 1);

-- Usamos MERGE para marcar presença, pois o registro pode ter sido criado automaticamente
MERGE INTO presenca p
USING (SELECT 1 as insc_id, 1 as a_id FROM dual) src
ON (p.inscricao_id = src.insc_id AND p.aula_id = src.a_id)
WHEN MATCHED THEN UPDATE SET p.presente = '1'
WHEN NOT MATCHED THEN INSERT (inscricao_id, aula_id, presente) VALUES (1, 1, '1');

PROMPT === TESTE 6: AVALIAÇÃO E NOTA ===
INSERT INTO avaliacao (id, titulo, data, data_entrega, peso, max_alunos, turma_id, tipo_avaliacao_id)
VALUES (1, 'Exame Final', SYSDATE, SYSDATE, 100, 1, 1, 1);

-- Inserção de nota deve disparar o cálculo de nota_final na inscrição e media_geral na matricula
INSERT INTO nota (inscricao_id, avaliacao_id, nota, comentario)
VALUES (1, 1, 18, 'Excelente desempenho');

COMMIT;

PROMPT =========================================================================
PROMPT === RESULTADOS DA VERIFICAÇÃO ===
PROMPT =========================================================================

COLUMN nome FORMAT A20;
COLUMN curso FORMAT A15;
COLUMN estado FORMAT A10;
COLUMN nota FORMAT 99.99;

PROMPT [ESTUDANTE]
SELECT nome, nif, email FROM estudante WHERE id = 1;

PROMPT [MATRICULA]
SELECT m.id, c.nome as curso, em.nome as estado, m.media_geral 
FROM matricula m 
JOIN curso c ON m.curso_id = c.id 
JOIN estado_matricula em ON m.estado_matricula_id = em.id;

PROMPT [NOTAS]
SELECT a.titulo, n.nota 
FROM nota n 
JOIN avaliacao a ON n.avaliacao_id = a.id 
WHERE n.inscricao_id = 1;

PROMPT [PROPINAS]
SELECT count(*) as parcelas, sum(valor) as total FROM parcela_propina WHERE matricula_id = 1;

PROMPT [LOGS]
SELECT acao, tabela, data FROM log WHERE rownum <= 5 ORDER BY created_at DESC;

