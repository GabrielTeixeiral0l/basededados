-- =============================================================================
-- 11. PACOTE DE BUFFER PARA CÁLCULO DE NOTAS
-- =============================================================================

CREATE OR REPLACE PACKAGE PKG_BUFFER_NOTA IS
    TYPE t_rec IS RECORD (
        inscricao_id NUMBER, 
        pai_id       NUMBER
    );
    
    TYPE t_tab IS TABLE OF t_rec INDEX BY BINARY_INTEGER;
    v_lista t_tab;

    TYPE t_insc IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
    v_lista_insc t_insc;

    TYPE t_mat IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
    v_lista_mat t_mat;

    v_executando BOOLEAN := FALSE;

    PROCEDURE LIMPAR;
    PROCEDURE ADICIONAR_PAI(p_insc_id IN NUMBER, p_pai_id IN NUMBER);
    PROCEDURE ADICIONAR_FINAL(p_insc_id IN NUMBER);
    PROCEDURE ADICIONAR_MATRICULA(p_mat_id IN NUMBER);
END PKG_BUFFER_NOTA;
/

CREATE OR REPLACE PACKAGE BODY PKG_BUFFER_NOTA IS
    PROCEDURE LIMPAR IS 
    BEGIN 
        v_lista.DELETE; 
        v_lista_insc.DELETE;
        v_lista_mat.DELETE;
    END LIMPAR;
    
    PROCEDURE ADICIONAR_PAI(p_insc_id IN NUMBER, p_pai_id IN NUMBER) IS
    BEGIN
        v_lista(v_lista.COUNT + 1).inscricao_id := p_insc_id;
        v_lista(v_lista.COUNT + 1).pai_id := p_pai_id;
    END ADICIONAR_PAI;

    PROCEDURE ADICIONAR_FINAL(p_insc_id IN NUMBER) IS
    BEGIN
        v_lista_insc(p_insc_id) := p_insc_id;
    END ADICIONAR_FINAL;

    PROCEDURE ADICIONAR_MATRICULA(p_mat_id IN NUMBER) IS
    BEGIN
        v_lista_mat(p_mat_id) := p_mat_id;
    END ADICIONAR_MATRICULA;
END PKG_BUFFER_NOTA;
/
