-- =============================================================================
-- 4. PACOTE DE GESTÃO DE DADOS (NOMES ORIGINAIS - CORREÇÃO SQLERRM)
-- =============================================================================

CREATE OR REPLACE PACKAGE PKG_GESTAO_DADOS IS
    FUNCTION DEVE_FAZER_SOFT_DELETE(p_tabela IN VARCHAR2) RETURN BOOLEAN;
    PROCEDURE PRC_LOG_ALERTA(p_msg IN VARCHAR2);
    PROCEDURE PRC_LOG_ERRO(p_contexto IN VARCHAR2);
    PROCEDURE PRC_REMOVER(p_nome_tabela IN VARCHAR2, p_id_registo IN NUMBER);
    PROCEDURE PRC_RECALCULAR_GPA(p_matricula_id IN NUMBER);
END PKG_GESTAO_DADOS;
/

CREATE OR REPLACE PACKAGE BODY PKG_GESTAO_DADOS IS

    FUNCTION DEVE_FAZER_SOFT_DELETE(p_tabela IN VARCHAR2) RETURN BOOLEAN IS
        v_tab VARCHAR2(30) := UPPER(p_tabela);
    BEGIN
        IF v_tab IN ('LOG', 'ESTADO_MATRICULA') THEN RETURN FALSE; END IF;
        RETURN TRUE;
    END DEVE_FAZER_SOFT_DELETE;

    PROCEDURE PRC_LOG_ALERTA(p_msg IN VARCHAR2) IS
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        INSERT INTO log (id, acao, tabela, data)
        VALUES (seq_log.NEXTVAL, 'ALERTA', 'SISTEMA', p_msg);
        COMMIT;
    EXCEPTION WHEN OTHERS THEN ROLLBACK;
    END PRC_LOG_ALERTA;

    PROCEDURE PRC_LOG_ERRO(p_contexto IN VARCHAR2) IS
        v_err VARCHAR2(4000) := SUBSTR(SQLERRM, 1, 4000);
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        INSERT INTO log (id, acao, tabela, data)
        VALUES (seq_log.NEXTVAL, 'ERROR_TECH', UPPER(p_contexto), v_err);
        COMMIT;
    EXCEPTION WHEN OTHERS THEN ROLLBACK;
    END PRC_LOG_ERRO;

    PROCEDURE PRC_REMOVER(p_nome_tabela IN VARCHAR2, p_id_registo IN NUMBER) IS
        v_sql        VARCHAR2(500);
        v_has_status NUMBER;
        v_tab        VARCHAR2(30) := UPPER(p_nome_tabela);
    BEGIN
        SELECT COUNT(*) INTO v_has_status FROM user_tab_columns 
        WHERE table_name = v_tab AND column_name = 'STATUS';

        IF v_has_status > 0 AND DEVE_FAZER_SOFT_DELETE(v_tab) THEN
            v_sql := 'UPDATE ' || v_tab || ' SET status = ''0'', updated_at = SYSDATE WHERE id = :1';
        ELSE
            v_sql := 'DELETE FROM ' || v_tab || ' WHERE id = :1';
        END IF;

        EXECUTE IMMEDIATE v_sql USING p_id_registo;

        IF SQL%ROWCOUNT = 0 THEN
            PRC_LOG_ALERTA('Remoção falhou: ID ' || p_id_registo || ' não encontrado em ' || v_tab);
        END IF;
    EXCEPTION WHEN OTHERS THEN PRC_LOG_ERRO('REMOVER_' || v_tab);
    END PRC_REMOVER;

    PROCEDURE PRC_RECALCULAR_GPA(p_matricula_id IN NUMBER) IS
        v_media     NUMBER; 
        v_ects      NUMBER; 
        v_cur_id    NUMBER; 
        v_total_obr NUMBER; 
        v_aprov     NUMBER;
    BEGIN
        -- Busca o curso da matricula
        SELECT curso_id INTO v_cur_id FROM matricula WHERE id = p_matricula_id;
        
        -- Calcula média ponderada pelos ECTS (considerando apenas a melhor nota de cada UC)
        SELECT SUM(max_nota * ects), SUM(ects) INTO v_media, v_ects
        FROM (
            SELECT MAX(i.nota_final) as max_nota, uc.ects
            FROM inscricao i 
            JOIN turma t ON i.turma_id = t.id 
            JOIN uc_curso uc ON (t.unidade_curricular_id = uc.unidade_curricular_id)
            WHERE i.matricula_id = p_matricula_id AND i.nota_final IS NOT NULL 
              AND i.status = '1' AND uc.curso_id = v_cur_id
            GROUP BY t.unidade_curricular_id, uc.ects
        );
          
        IF v_ects > 0 THEN 
            UPDATE matricula SET media_geral = (v_media / v_ects), updated_at = SYSDATE 
            WHERE id = p_matricula_id; 
        END IF;
        
        -- Verifica se concluiu todas as UCs do curso
        SELECT COUNT(*) INTO v_total_obr FROM uc_curso WHERE curso_id = v_cur_id AND status = '1';
        
        SELECT COUNT(DISTINCT t.unidade_curricular_id) INTO v_aprov 
        FROM inscricao i 
        JOIN turma t ON i.turma_id = t.id
        WHERE i.matricula_id = p_matricula_id 
          AND i.nota_final >= PKG_CONSTANTES.NOTA_APROVACAO 
          AND i.status = '1';
          
        IF v_aprov >= v_total_obr AND v_total_obr > 0 THEN 
            UPDATE matricula SET estado_matricula_id = PKG_CONSTANTES.EST_MATRICULA_CONCLUIDA 
            WHERE id = p_matricula_id; 
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN NULL;
        WHEN OTHERS THEN PRC_LOG_ERRO('RECALCULAR_GPA_' || p_matricula_id);
    END PRC_RECALCULAR_GPA;

END PKG_GESTAO_DADOS;
/